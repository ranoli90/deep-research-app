# Builder handoff — revision 3
This version supersedes the previous emailed reviewed ZIP and goal. Read README.md, AGENTS.md, STATUS.md, Grok_Code_Deep_Research_Goal.md and IMPLEMENTATION_PLAN.md; then the relevant contracts. `docs/PREBUILD_RECONCILIATION.md` explains how every requested review change was resolved.

Use the full current files. The obsolete v1-to-v2 patch is intentionally not included as a build input. No executable patch is supplied in this revision; the full canonical files and before/after hash changeset are supplied instead. Inspect existing source and preserve working code/user changes.

First checkpoint: P0-D local deterministic/database correctness, P0-L authorized live evidence/report/correction and P0-N actual native lifecycle per platform. Build minimum consent/ownership/budget/cancel/delete/publication fences and code governance now. Keep basic controls accessible. Do not build full settings, purchase, live push or decorative shell breadth first.

Real local PostgreSQL/queue is valid for executed transaction/recovery tests without cloud provisioning. It does not prove hosted Supabase/Render auth/storage/pooler parity. Missing a live key or an iOS runtime leaves that gate blocked, not passed; other safe work continues. Named blockers are correct reports, not completed implementation.

F04/F06 are already resolved in specification text, not implemented in an app. Notification identity is logical `(runId, completionEpoch)` with per-binding delivery state; never translate that into an external exactly-once guarantee. Read engine §10 and J02/J14/S12 before implementation.

Keep the twelve task seeds draft until actual consented tasks and independent decisive evidence are prepared. Baseline/control/repair comparisons remain experiments. No claim of advantage from documentation tests or the second AI's favorable verdict.

At each checkpoint report actual commit or not-a-repository, commands, exit codes, fixture/live/native scope, build/device identity, artifacts, blocked inputs and next executable task. The reviewed ZIP includes no app package.json or working pnpm scripts; implement and register them before use. Live calls/services/stores require project-specific authorization.
