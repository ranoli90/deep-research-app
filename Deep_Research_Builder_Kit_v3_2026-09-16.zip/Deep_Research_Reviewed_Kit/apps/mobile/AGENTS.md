# Mobile scoped instructions

Root AGENTS.md applies; these rules cannot weaken it.

**Current status:** No native source is present yet. These instructions govern future native code in this directory.

Import only public contracts and design/client code. Never call model providers with developer secrets. Screens contain presentation, not orchestration or billing policy. Test keyboard/safe areas/back behavior, large text, source-sheet return, offline/reconnect and process death. Read specs/MOBILE_SCREEN_STATES.md. Actual iOS/Android evidence is required; browser previews do not substitute.

Use verification/COMMANDS.json to distinguish available and proposed checks. Update the owning canonical spec with behavior changes, not a duplicate local handbook.

Revision 3: build usable accessible P0 composer/reader and lifecycle recovery before decorative P3 breadth. Source selection and account authorization apply to incoming links even after logout; an in-flight remote alert cannot be recalled by claiming client-side deduplication.
