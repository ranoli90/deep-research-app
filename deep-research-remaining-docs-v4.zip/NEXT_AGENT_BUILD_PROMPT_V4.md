# Next Agent Build Prompt V4

You are taking over `ranoli90/deep-research-app` after a substantial implementation pass.

Do not rewrite the application blindly. Inspect the current repository and prove the state.

## Primary objective

Move the project from a strong engineering baseline with a bounded live route to the intended adaptive deep-research product.

Target loop:

> Understand the task and hard constraints → identify what must be known → search beyond obvious results → inspect decisive sources → detect gaps/contradictions → pivot source type when needed → verify consequential claims → stop when additional work has low decision value → produce a cited report with localized uncertainty → safely repair it when assumptions/evidence change.

## Critical finding

The OpenRouter model-action adapter exists, but the live worker currently selects actions through `nextLiveAction()`.

Do not hide this. Either wire the model planner into a safe typed controller or prove through benchmark evidence that a deterministic controller meets the product requirements.

## Required implementation

### Typed controller
Support search, fetch, extraction, comparison, calculation, verification, replanning, synthesis and stop. Every model proposal must pass schema, authorization, privacy, spend, source-access, dedupe and revision/fence checks.

### Research questions/gaps
Persist research questions, required evidence, status, why the evidence matters, source type needed, attempted routes and latest outcomes. Do not derive the whole research plan from regexes or report templates.

### Adaptive source strategy
When a decision-critical gap remains, change query formulation or source type, seek primary/official evidence when appropriate, seek independent evidence when independence matters, inspect documents rather than relying on snippets, and record why the pivot occurred.

### Disconfirmation
Consequential claims must be eligible for a verification action that attempts to falsify or qualify them.

### Stop policy
Stop on evidence sufficiency, low marginal decision value, budget limits or unavoidable access constraints. Explain consequential unresolved gaps.

### Corrections
Replace narrow correction regexes with typed correction intents. Track dependencies so the system can determine what changed, what conclusions are affected, what candidates become newly eligible/ineligible, what evidence is stale, whether selective recomputation is safe, and when a full rerun is mandatory.

### Benchmark
Build an adjudicated set covering constrained comparisons, conflicting claims, niche research, document/web synthesis, purchase decisions, technical tradeoffs and changed-assumption follow-ups. Compare baseline vs adaptive behavior using the same model/provider.

## Security

Retrieved content must never be allowed to reveal secrets, grant tools, change policy, purchase anything, bypass spend limits, bypass privacy/consent or alter tenant ownership. Preserve SSRF and redirect protections.

## Mobile

After the research engine is credible, complete iOS verification, VoiceOver, two-platform lifecycle, offline/reconnect, source inspection, correction, deletion, sharing, purchase sandbox and push transport.

## Definition of done

1. Live controller is genuinely adaptive or a deterministic alternative is benchmarked and justified.
2. Live evidence is persisted and cited.
3. Decision-critical gaps can trigger source-type pivots.
4. Consequential claims can trigger verification.
5. Corrections safely invalidate affected work.
6. Benchmark results are recorded.
7. Fixture results are never presented as live-quality evidence.
8. Stale/deleted/private data cannot be published.
9. Cost and outcome-unknown behavior remain fail-closed.
10. Documentation matches actual code.

Do not stop at a plan. Implement, test, verify and record evidence.
