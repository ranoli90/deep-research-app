# Verification Matrix V4

**Purpose:** prevent implementation claims from being confused with evidence.

| Area | Current state | Required next proof |
|---|---|---|
| Postgres + queue | Verified locally | CI/staging repeat |
| Worker fencing | Verified locally | hosted failure drill |
| Cancellation | Verified local + Android | iOS device |
| Consent revocation | Verified locally | hosted end-to-end |
| Deletion | Local + Android flow | hosted end-to-end deletion |
| SSRF redirect defense | Unit verified | staging/security probe |
| Citation ownership | Integration verified | live benchmark |
| Live web search | Bounded live proof | repeated controlled trials |
| Live full-text fetch | Bounded live proof | diverse access/source tests |
| Model-directed planning | **Open**; adapter exists but live worker bypasses it | wire/benchmark planner |
| Adaptive source pivot | Fixture verified | live same-model benchmark |
| Evidence-gap detection | Fixture verified | live benchmark |
| Contradiction handling | Fixture verified | adjudicated benchmark |
| Correction reopening | Baseline verified | generalized dependency engine |
| Selective recomputation | Fixture verified | ablation vs full rerun |
| Android lifecycle | Device evidence | regression run |
| iOS lifecycle | Blocked | macOS/Xcode/device |
| Android accessibility | Device evidence | regression run |
| iOS accessibility | Not exercised | VoiceOver |
| Hosted auth/RLS | Not proven | staging deployment |
| Hosted storage | Not proven | staging deployment |
| Purchases | Sandbox not connected | store sandbox |
| Push | App outbox only | actual OS delivery |
| Store webhooks | Not proven | signed webhook test |
| Live invoice reconciliation | Not proven | controlled invoice test |
| Research benchmark | Open | adjudicated benchmark + baseline |
| Competitor comparison | Open | matched same-task trials |
| Backups/restore | Open | restore drill |
| Production rollout | Open | staged deployment |

## Evidence rule

Every release claim must identify the exact command/device, environment, commit, scenario, result and limitations, and classify evidence as fixture, live, native or hosted.

A green deterministic suite does not turn a live, native, hosted or research-quality gate green.

## Minimum research-quality benchmark

Compare a baseline controller against an adaptive controller using the same model/provider, task set and budget policy.

Record:

- citation correctness
- decisive-evidence recall
- hard-constraint violations
- unsupported claims
- contradiction handling
- correction accuracy
- latency
- cost
