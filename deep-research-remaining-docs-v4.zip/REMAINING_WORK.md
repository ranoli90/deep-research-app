# Remaining Work — Post-Implementation Build Plan

**Date:** 2026-09-17  
**Repository:** `ranoli90/deep-research-app`  
**Branch reviewed:** `main`  
**Reviewed commit:** `8c75889b4f293f9f79c28b9ea1aff34076d21475`

## Current position

The repository is no longer a planning-only kit. It contains a runnable TypeScript monorepo with a React Native/Expo mobile app, backend API and durable PostgreSQL/pg-boss worker, shared contracts, research-core, evidence/source/version/passage/claim/report structures, deterministic integration coverage, a bounded live route using OpenRouter web search plus safe HTTP fetching, and meaningful Android device verification.

The major remaining gap is **research intelligence**, not basic application plumbing.

The current live controller is deliberately bounded: discovery → inspect a limited set of known URLs → synthesize. The OpenRouter action-planner adapter exists, but the worker's live route currently chooses actions through the app-owned `nextLiveAction()` controller. Therefore the system has a real live retrieval/report path, but it is not yet the adaptive, model-directed research system described by the product goal.

Do not describe fixture behavior or this bounded live route as proof that the product is better than ChatGPT, Gemini, Claude, Perplexity or Grok.

## Priority order

### P0 — Close release blockers

1. iOS native verification on macOS/Xcode.
2. iOS VoiceOver/accessibility verification.
3. Complete two-platform G03 lifecycle evidence.
4. Verify hosted authentication, authorization/RLS, storage and production DB/pooler behavior.
5. Connect and test purchase sandbox behavior.
6. Verify actual OS push transport; application-level outbox deduplication is not delivery proof.
7. Verify signed store webhooks if subscriptions ship.
8. Establish production secrets, environment separation, backups, migrations and rollback.

### P1 — Build real research intelligence

1. Define a typed controller interface for search, fetch, extraction, comparison, calculation, verification, replanning and synthesis.
2. Connect the model planner through the existing provider adapter instead of bypassing it.
3. Keep model proposals behind deterministic authorization, cost, privacy and source-access policy.
4. Persist research questions and evidence gaps as first-class objects.
5. Measure source-family coverage and independence.
6. Pivot source type when the current source type cannot answer a decision-critical gap.
7. Add explicit disconfirmation for consequential claims.
8. Stop based on evidence sufficiency, marginal decision value and budget.
9. Preserve localized uncertainty when evidence remains incomplete.

### P2 — Generalize correction-safe research

1. Replace regex-only correction interpretation with typed correction intents.
2. Persist dependencies from conclusions/candidates/claims to constraints, evidence and calculations.
3. Compute conservative impact sets when facts change.
4. Reopen only affected candidate/evidence spaces when safe.
5. Fall back to a bounded full rerun when dependency completeness is unknown.
6. Generate user-visible change summaries.
7. Prevent stale versions from publishing after concurrent corrections.
8. Preserve deletion/tombstone semantics across every version.

### P3 — Prove research-quality differentiation

Build an adjudicated benchmark covering hard-constraint comparisons, conflicting claims, niche research, document/web reconciliation, purchase decisions, technical tradeoffs, and changed-assumption follow-ups.

Measure citation correctness, constraint adherence, decisive-evidence recall, contradiction handling, unsupported-claim rate, correction accuracy, latency and cost.

Run same-model baseline comparisons and ablations for adaptive planning, evidence-gap detection, source-type pivots and selective correction.

### P4 — Finish native product quality

Review both platforms for large text, screen readers, keyboard behavior, offline/reconnect, interrupted runs, partial results, errors, account switching, deletion, sharing/export and deep links. Remove engineering-demo artifacts and keep progress UI tied to real persisted state.

### P5 — Production operations and economics

Reconcile provider usage against invoices; enforce per-run allowances including outcome-unknown calls; add redacted observability; exercise retry/lease/recovery monitoring; perform backup/restore drills; add rate limiting; verify deletion in every storage layer; add CI gates; define staged rollout and rollback.

## Do not do yet

- No multi-agent swarm without measured value.
- No graph/vector/orchestration platform without a demonstrated requirement.
- No broad connector expansion before the core web/document loop is reliable.
- No exhaustive-research claims.
- No competitor-superiority claims before matched trials.
- No casual live-provider spending.
- No treating fixture test counts as live research-quality evidence.

## Product-ready definition

A controlled launch requires applicable native, hosted, security, privacy, purchase and operational gates plus benchmark evidence that the research engine solves the intended jobs.

A polished shell around a fixed search/fetch/write loop is not the target. The target is a dependable research system that understands constraints, identifies missing decisive evidence, adapts investigation, verifies important claims, exposes uncertainty, and safely repairs previous work when assumptions change.
