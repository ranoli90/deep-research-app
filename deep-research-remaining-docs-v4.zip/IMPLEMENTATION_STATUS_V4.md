# Implementation Status V4 — Repository-Grounded Audit

**Reviewed:** 2026-09-17  
**Repository:** `ranoli90/deep-research-app`  
**HEAD:** `8c75889b4f293f9f79c28b9ea1aff34076d21475`

## Overall state

**Engineering baseline:** substantial and real.  
**Research engine:** early live baseline, not yet the intended adaptive system.  
**Android:** meaningful device verification completed.  
**iOS:** blocked by environment.  
**Production readiness:** not established.

## Verified / strongly evidenced

### Architecture
The tree has clear boundaries for `apps/backend`, `apps/mobile`, `packages/contracts`, `packages/research-core`, `agents`, `specs`, `verification`, `research` and `docs`. Scoped AGENTS files and runtime-role contracts are present.

### Backend reliability
The implementation includes PostgreSQL migrations, pg-boss queue integration, worker leases/fences, cancellation epochs, consent epochs, deletion checks, stale-publication protection, idempotent evidence insertion, crash/recovery paths and spend intent/settlement records.

### Evidence architecture
The code models sources, source versions, passages, claims, evidence gaps, candidates, reports, report versions and citations. Report citation validation checks referenced passages and claim support.

### Security/privacy
Observed controls include bearer-token hashing, consent checks, consent-revocation fencing, account deletion/tombstoning, private-content redaction, SSRF redirect revalidation, untrusted-source injection handling and no provider keys in the mobile bundle.

### Mobile
The repository contains a real Expo/React Native app and tests. The handoff records Android-device verification for close/reopen persistence, library reopening, source inspection, attachment ingestion, sharing, correction, cancellation during writing, TalkBack labels, enlarged text, offline behavior, follow-up and deletion-page navigation.

## Not verified / incomplete

### iOS
No Xcode environment was available in the recorded run. iOS build/device execution, VoiceOver and two-platform G03 remain open.

### Hosted production
Hosted auth, production authorization/RLS, storage, DB/pooler behavior, networking and backups are not established.

### Purchases/push/store
Purchase sandbox, signed store webhooks and actual OS push delivery are not established.

## Most important architectural finding

`apps/backend/src/adapters/model/openrouter.ts` implements a model-action proposal function, but the live worker currently chooses actions through `apps/backend/src/worker/live-policy.ts` and `nextLiveAction()`.

The live route is therefore genuinely connected to live retrieval, but it is **not yet a model-directed adaptive research controller**.

That is the most important gap between the current implementation and the intended product.

## Research-core limitation

The core has meaningful abstractions for constraints, gaps, candidates, calculations, support and reports. However, constraint extraction and correction parsing remain narrow/pattern-based. That is suitable for a controlled baseline but not a final general-purpose intent/constraint layer.

## Report-generation limitation

The report composer is evidence-aware and citation-aware, but portions of synthesis remain specialized around recognizable fixture scenarios such as candidate listings, percentages, compatibility limitations and corrections. General research decisions should move into typed controller outputs while report rendering remains generic.

## Bottom line

The project has crossed from specification to a credible engineering baseline.

It has not yet demonstrated a best-in-class deep-research engine. The next serious work should concentrate on the live adaptive research loop and its benchmark while closing the remaining platform and production gates.
